package com.example.familyplanner;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FamilyPlannerApplicationTests {

	@Test
	void contextLoads() {
	}

}
